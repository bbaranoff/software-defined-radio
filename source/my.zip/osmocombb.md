# OsmocomBB

**OsmocomBB** (Osmocom Baseband) is an open-source project that implements a GSM “baseband” stack for certain Motorola phones and SDR setups.

## What is OsmocomBB?

- **Mobile-side GSM protocol stack (MS, mobile station)**
- Replaces the original firmware to provide access to GSM Layer 1/2/3, protocol logging, sniffing, and testing
- Useful for: analysis, security testing, academic research, IMSI catchers, and radio fuzzing

## Architecture

- **host/osmocon**: Tool for loading the firmware onto supported devices
- **src/host/layer23**: GSM stack running on the PC (calls, SMS, sniffing, burst capture, etc.)
- **firmware/**: Baseband code to flash onto compatible phones

## Supported Hardware

- **Motorola C1xx series (C123, C118, C155, etc.)**
- Some other “Calypso” chipset-based models

## Use Cases & Limitations

- Can connect to a real 2G cell or an Osmocom BTS (osmo-bts-trx)
- Limited to pure 2G (no 3G/4G support)
- **Warning:** Transmitting without a license is illegal!  
  Use only for research or in controlled environments.

## Useful Links

- [OsmocomBB GitHub repository](https://github.com/osmocom/osmocom-bb)
- [Official Wiki](https://osmocom.org/projects/baseband/wiki/OsmocomBB)
- [Installation Guide (French)](https://www.lafabriquedunet.fr/blog/osmocombb-guide/)

---

**For SDR:** An experimental project exists to link OsmocomBB to an SDR (BladeRF, HackRF, etc.) via the “virtual layer1” interface.

