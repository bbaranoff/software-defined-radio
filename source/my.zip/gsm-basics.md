# GSM Basics: Overview

**GSM** (Global System for Mobile Communications) is the most widely used cellular standard in the world, originally designed for 2G voice and SMS, and later extended to data (GPRS/EDGE).

---

## What is GSM?

- **Digital** cellular standard for mobile voice and data
- Launched in Europe in 1991; adopted globally
- 900/1800 MHz (EU/Asia), 850/1900 MHz (Americas)

---

## Core Concepts

- **Cellular network**: Divides coverage into “cells,” each served by a Base Station
- **SIM card**: Holds subscriber identity and keys
- **Voice, SMS, low-rate data**: Core services (with later upgrades for Internet access)

---

## GSM Architecture

- **MS (Mobile Station)**: Your phone (hardware + SIM)
- **BTS (Base Transceiver Station)**: “Cell tower” – handles radio link with phones
- **BSC (Base Station Controller)**: Manages multiple BTS, handles handover and resources
- **MSC (Mobile Switching Center)**: Switches calls/SMS, manages mobility and authentication
- **HLR/VLR (Home/Visitor Location Register)**: Databases for subscriber info and roaming
- **AUC**: Authentication Center (manages SIM/IMSI/Ki)
- **EIR**: Equipment Identity Register (blocks stolen phones)

```

\[MS] ⇄ \[BTS] ⇄ \[BSC] ⇄ \[MSC] ⇄ \[HLR/VLR]

```

---

## Frequency & Modulation

- **TDMA**: Time Division Multiple Access (multiple users per frequency, via timeslots)
- **GMSK**: Gaussian Minimum Shift Keying (modulation for efficient, robust RF)

---

## Security & SIM

- Each SIM has a unique **IMSI** and a secret **Ki** key
- **Authentication**: Uses A3/A8 algorithms, with session keys (Kc) for each call

---

## Next Steps

- [OsmocomBB, SDR & GSM Hacking](osmocombb.md)
```

---

## **2. gsm-air.md**

(Focus: radio, air interface, protocol stack, channel types, how calls/SMS/data actually work)

```markdown
# GSM Air Interface & Protocol Stack

GSM’s “air interface” defines how your phone communicates with the network over the radio channel, including frequency usage, timeslots, and protocol layers.

---

## Radio Channels & Timeslots

- **Frequency bands**: GSM900, 1800, 850, 1900 MHz
- **Channel** = carrier frequency (200 kHz wide) divided into 8 **timeslots** (TDMA)
- **One user** = one timeslot per frame (except for control channels or “packet” data)

---

## Channel Types

- **Traffic Channels (TCH)**: Carry voice or user data
- **Control Channels (CCH)**:
    - **BCCH**: Broadcast Control (network info, cell parameters)
    - **CCCH**: Common Control (paging, access grant)
    - **DCCH**: Dedicated Control (setup, authentication, SMS signaling)

---

## Protocol Stack

- **Layer 1 (Physical)**: Handles modulation, RF transmission (GMSK)
- **Layer 2 (Data Link)**: LAPDm – error correction, framing
- **Layer 3 (Network)**: RR/MM/CC – radio resource management, mobility, call control

```

\[Application]
↓
\[Layer 3: RR/MM/CC]
↓
\[Layer 2: LAPDm]
↓
\[Layer 1: RF]

```

---

## Call Flow (Simplified)

1. **Power on** → Phone scans BCCH, selects best cell
2. **Registration** → Sends IMSI, network authenticates SIM
3. **Call/SMS** → Signaling on DCCH, voice/data on TCH
4. **Handover** → If moving, network switches BTS/BSC
5. **Encryption** → Stream cipher (A5/1 etc.) enabled after authentication

---

## Packet Data

- **GPRS/EDGE**: Uses extra timeslots for data (“packet channels”), handled by SGSN/GGSN in the core
- **Data rates**: From ~9.6 kbps (GSM) to 236 kbps (EDGE)

---

## See Also

- [OsmocomBB](osmocombb.qmd)
- [A5/1 Encryption](a51.qmd)
- [SDR Experiments](edge.qmd)

```

---

**Want a diagram, more detail, or French translation?**
Just ask—these two pages are ready for Quarto, MkDocs, Sphinx (with MyST), or even classic Markdown!
